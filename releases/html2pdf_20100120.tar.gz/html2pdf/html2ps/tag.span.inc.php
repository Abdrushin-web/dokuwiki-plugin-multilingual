<?php
// $Header: /cvsroot/html2ps/tag.span.inc.php,v 1.3 2005/08/21 08:24:35 Konstantin Exp $
?>